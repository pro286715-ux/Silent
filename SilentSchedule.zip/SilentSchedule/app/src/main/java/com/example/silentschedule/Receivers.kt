package com.example.silentschedule

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val silent = i.getBooleanExtra(Scheduler.EXTRA_SILENT, false)
        Scheduler.setSilent(c, silent)
        // перепланировать на завтра
        if (Scheduler.prefs(c).getBoolean("enabled", false)) Scheduler.scheduleAll(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Scheduler.prefs(c).getBoolean("enabled", false)) Scheduler.scheduleAll(c)
    }
}
