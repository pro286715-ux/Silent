package com.example.silentschedule

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import java.util.Calendar

object Scheduler {
    const val EXTRA_SILENT = "silent"
    private const val REQ_START = 1
    private const val REQ_END = 2

    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun isSilent(c: Context): Boolean =
        c.getSystemService(AudioManager::class.java).ringerMode != AudioManager.RINGER_MODE_NORMAL

    /** Включает/выключает беззвучный режим. Без доступа к «Не беспокоить» ставится вибро. */
    fun setSilent(c: Context, on: Boolean) {
        val am = c.getSystemService(AudioManager::class.java)
        val nm = c.getSystemService(NotificationManager::class.java)
        try {
            am.ringerMode = when {
                !on -> AudioManager.RINGER_MODE_NORMAL
                nm.isNotificationPolicyAccessGranted -> AudioManager.RINGER_MODE_SILENT
                else -> AudioManager.RINGER_MODE_VIBRATE
            }
        } catch (e: SecurityException) {
            // нет разрешения — ничего не делаем
        }
    }

    fun scheduleAll(c: Context) {
        val p = prefs(c)
        schedule(c, REQ_START, p.getInt("start", 22 * 60), true)
        schedule(c, REQ_END, p.getInt("end", 7 * 60), false)
    }

    fun cancelAll(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(pending(c, REQ_START, true))
        am.cancel(pending(c, REQ_END, false))
    }

    /** Ставит будильник на ближайшее наступление времени (minutes от полуночи). */
    fun schedule(c: Context, req: Int, minutes: Int, silent: Boolean) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutes / 60)
            set(Calendar.MINUTE, minutes % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pending(c, req, silent)
        if (am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    private fun pending(c: Context, req: Int, silent: Boolean) = PendingIntent.getBroadcast(
        c, req,
        Intent(c, AlarmReceiver::class.java).putExtra(EXTRA_SILENT, silent),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
