package com.example.silentschedule

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private lateinit var sw: Switch

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggleNow)
        startBtn = findViewById(R.id.startTime)
        endBtn = findViewById(R.id.endTime)
        sw = findViewById(R.id.scheduleSwitch)

        val p = Scheduler.prefs(this)
        sw.isChecked = p.getBoolean("enabled", false)

        toggle.setOnClickListener {
            Scheduler.setSilent(this, !Scheduler.isSilent(this))
            refresh()
        }
        startBtn.setOnClickListener { pickTime("start", 22 * 60) }
        endBtn.setOnClickListener { pickTime("end", 7 * 60) }
        sw.setOnCheckedChangeListener { _, on ->
            p.edit().putBoolean("enabled", on).apply()
            if (on) { ensurePermissions(); Scheduler.scheduleAll(this) } else Scheduler.cancelAll(this)
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun pickTime(key: String, def: Int) {
        val p = Scheduler.prefs(this)
        val cur = p.getInt(key, def)
        TimePickerDialog(this, { _, h, m ->
            p.edit().putInt(key, h * 60 + m).apply()
            if (sw.isChecked) Scheduler.scheduleAll(this)
            refresh()
        }, cur / 60, cur % 60, true).show()
    }

    /** Просим доступ к «Не беспокоить» и к точным будильникам, если ещё нет. */
    private fun ensurePermissions() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted)
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        else if (!getSystemService(AlarmManager::class.java).canScheduleExactAlarms())
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
    }

    private fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)

    private fun refresh() {
        val p = Scheduler.prefs(this)
        val silent = Scheduler.isSilent(this)
        status.text = if (silent) "🔕 Беззвучный режим включён" else "🔔 Звук включён"
        toggle.text = if (silent) "Выключить беззвучку" else "Включить беззвучку"
        startBtn.text = "Включать беззвучку в: " + fmt(p.getInt("start", 22 * 60))
        endBtn.text = "Выключать беззвучку в: " + fmt(p.getInt("end", 7 * 60))
    }
}
